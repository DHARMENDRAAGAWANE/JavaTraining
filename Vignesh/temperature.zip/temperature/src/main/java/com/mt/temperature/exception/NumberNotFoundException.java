package com.mt.temperature.exception;

public class NumberNotFoundException extends RuntimeException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3668749861201357050L;

	public NumberNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}	
	
}
